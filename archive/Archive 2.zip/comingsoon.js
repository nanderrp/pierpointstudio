window.onload = function(){
document.getElementById("fade").style.opacity = 1;
document.getElementById("soon").style.opacity = 1;
};
